Simple example
--------------

* `Tiny project with GTest <https://github.com/forexample/hunter-simple>`_
