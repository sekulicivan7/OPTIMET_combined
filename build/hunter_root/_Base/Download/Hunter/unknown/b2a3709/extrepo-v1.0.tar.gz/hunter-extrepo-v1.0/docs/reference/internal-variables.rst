Internal variables
------------------
