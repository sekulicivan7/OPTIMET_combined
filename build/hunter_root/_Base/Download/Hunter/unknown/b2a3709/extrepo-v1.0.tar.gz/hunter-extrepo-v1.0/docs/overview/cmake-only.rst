CMake only
----------

No other dependencies - **just CMake** and your environment/IDE (no need for
Git or Python or anything).
