Manage anything
---------------

.. _manage-anything:

You can manage anything that can be downloaded by ``URL`` and checked with
``SHA1`` hash:

* C++ packages
* CMake modules
* Additional sources
* Resources (pictures, data for testing, ...)
