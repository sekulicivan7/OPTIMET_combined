Compatibility
-------------

Backward compatibility.

Turn Hunter off by adding one option `HUNTER_ENABLED=OFF`_ to use your old
settings.

.. _HUNTER_ENABLED=OFF: https://github.com/ruslo/hunter/wiki/usr.variables#hunter_enabled
