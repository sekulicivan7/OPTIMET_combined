Hunter developer
----------------

* reference to modules
* layout guide
