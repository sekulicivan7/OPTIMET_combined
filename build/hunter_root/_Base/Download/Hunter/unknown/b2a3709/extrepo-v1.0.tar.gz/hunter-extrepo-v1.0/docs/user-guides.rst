User guides
-----------

Guides splitted into sections by role of developer in project. Sections should
be read sequentinally one by one.

.. toctree::
   :maxdepth: 1
   
   /user-guides/regular
   /user-guides/cmake-user
   /user-guides/hunter-user
   /user-guides/hunter-developer
