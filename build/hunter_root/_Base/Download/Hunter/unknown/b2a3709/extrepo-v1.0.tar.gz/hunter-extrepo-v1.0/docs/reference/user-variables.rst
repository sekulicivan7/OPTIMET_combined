User variables
--------------

* List of global control `variables <https://github.com/ruslo/hunter/wiki/usr.variables>`_
