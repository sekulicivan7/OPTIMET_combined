Donations
---------

* `Donations <https://github.com/ruslo/hunter/blob/develop/donate.md>`_
