CMake (with dependencies)
-------------------------
