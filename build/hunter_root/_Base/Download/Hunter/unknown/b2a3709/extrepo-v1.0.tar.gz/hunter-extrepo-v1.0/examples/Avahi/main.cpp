#include <avahi-client/client.h>
#include <avahi-compat-libdns_sd/dns_sd.h>

int main(int argc, char** argv) {
}
