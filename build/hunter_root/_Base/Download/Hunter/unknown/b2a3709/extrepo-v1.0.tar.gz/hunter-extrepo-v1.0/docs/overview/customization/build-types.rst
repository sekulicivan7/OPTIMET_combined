Build types
-----------

* `Build types like Release/Debug <https://github.com/ruslo/hunter/wiki/usr.variables#hunter_configuration_types>`_
