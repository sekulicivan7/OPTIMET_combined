Non-CMake: custom scheme
------------------------

* How to add a new `custom-build project`_

.. _custom-build project: https://github.com/ruslo/hunter/wiki/usr.adding.new.package.custom.scheme
