Terminology
-----------

* CMake cache
* Hunter cache
* Binary cache server
