CMake (no dependencies)
-----------------------

* How to add a new `CMake project`_

.. _CMake project: https://github.com/ruslo/hunter/wiki/usr.adding.new.package
