CMake user
----------

This is quite the same as C++ developer.

* do not add dependencies
* no c++flags (only warnings)
* add more sources
* add more targets
